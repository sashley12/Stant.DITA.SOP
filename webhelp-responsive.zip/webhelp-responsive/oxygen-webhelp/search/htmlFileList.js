//List of files which are indexed.
fl = new Array();
fl["0"]= "c-shanksicm.html";
fl["1"]= "t-cleaning.html";
fl["2"]= "t-freezerbowl.html";
fl["3"]= "t-mangofroyo.html";
fl["4"]= "t-raspberrysorbet.html";
fl["5"]= "t-vanilla.html";
var doStem = false;searchLoaded = true;