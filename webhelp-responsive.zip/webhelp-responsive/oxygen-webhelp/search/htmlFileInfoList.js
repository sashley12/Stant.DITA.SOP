fil = new Array();
fil["0"]= "c-shanksicm.html@@@Shanks Hall s Frozen Dessert Machine@@@Shanks Hall has a new Frozen Dessert Machine for students and faculty!...";
fil["1"]= "t-cleaning.html@@@How to Clean the Frozen Dessert Machine@@@The machine must be cleaned before it is used for the first time. The machine also must be cleaned after every use...";
fil["2"]= "t-freezerbowl.html@@@How to Prepare the Freezer Bowl@@@The freezer bowl must be frozen before use in order for a frozen dessert to be made successfully...";
fil["3"]= "t-mangofroyo.html@@@How to Make Mango Frozen Yogurt@@@Frozen Yogurt is a healthy alternative to ice cream. Mango frozen yogurt offers a sweet, fruity taste!...";
fil["4"]= "t-raspberrysorbet.html@@@How to Make Raspberry-Mint Sorbet@@@Raspberry-mint sorbet makes for a great light and refreshing treat with less calories and fat than ice cream...";
fil["5"]= "t-vanilla.html@@@How to Make Creamy Vanilla Ice Cream@@@Vanilla ice cream is one of the most popular flavors out there: a classic favorite!...";
